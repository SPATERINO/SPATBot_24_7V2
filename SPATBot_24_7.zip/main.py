from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters
import random
from keep_alive import keep_alive

# 🔑 Tava bota API token (importē no Secrets Replitā)
import os
TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN")

# 🎵 YouTube chill vibes
vibe_links = ["https://www.youtube.com/watch?v=suYOayE3e00"]

# 🧠 Komandas
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("🟢 SPATBot is online. Ready to flip rugs and drop bars. 🥄")

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🧠 Commands:\n"
        "/gm – SPATBot says hi 👋\n"
        "/rug – sends a rug alert ⚠️\n"
        "/wen – drops a wisdom nugget 🌕\n"
        "/flipme – flip yourself for good luck 🥞\n"
        "/vibe – drop a random chill YouTube link 🎧\n"
        "/flipverse – unlock hidden lore 🧪\n"
        "/twitter – check the official Twitter 🔗\n\n"
        "Say: gm, rug, or wen moon to trigger hidden flips 🥄"
    )

async def flipme(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("You got flipped like a pancake, fren 🥞🥄")

async def vibe(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(random.choice(vibe_links))

async def twitter(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("📡 Follow us on Twitter: https://twitter.com/TheRealSpatCoin")

async def flipverse(update: Update, context: ContextTypes.DEFAULT_TYPE):
    flip_quotes = [
        "🌌 Deep within the metaverse, one coin flips them all.",
        "🥄 Born from rugs, risen through memes — $SPAT is not a coin. It's a movement.",
        "🚫 We don’t chase rugs. We flip 'em and leave no crumbs.",
        "💡 Those who HODL the spatula, hold the power to cleanse the chain.",
        "📜 Legends say $SPAT was forged in the kitchens of justice.",
        "⚔️ One spatula to flip them all, one meme to rug them.",
        "🔥 You are not early. You are chosen.",
        "👨‍🍳 Behind every rug, there’s a SPAT waiting in the shadows.",
        "💥 The blockchain is our stove. And rugs? They’re dinner.",
        "🌀 Some hold coins. We hold justice. $SPAT forever.",
        "🥶 Cold wallets, warm flips. Welcome to SPATverse.",
        "🌪️ From the ashes of rugs, rises the pan of destiny.",
        "🎭 Not financial advice. Just pancake prophecy.",
        "🧠 Real degens use spatulas — not trust.",
        "🥄 The spatula chooses the flipper. Always.",
        "📈 We flip rugs like burgers. Fast and well-done.",
        "🚀 To the moon? Nah. To the kitchen, baby.",
        "🧂 Sprinkle salt on scammers. Then flip.",
        "💭 The deeper you think, the crispier the rug.",
        "😤 Others make promises. We just flip."
    ]
    await update.message.reply_text(random.choice(flip_quotes))

# 🧠 Trigger vārdi
async def trigger_words(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.lower()
    if "gm" in text:
        await update.message.reply_text("👋 GM fren 🌞 Let’s flip this day.")
    elif "rug" in text:
        await update.message.reply_text("⚠️ Rug alert! SPAT army is on it.")
    elif "wen moon" in text:
        await update.message.reply_text("🌕 When you flip enough rugs, the moon flips back.")

# 👋 Welcome + Help
async def welcome(update: Update, context: ContextTypes.DEFAULT_TYPE):
    for user in update.message.new_chat_members:
        await update.message.reply_text(
            f"👋 Welcome {user.mention_html()} to the SPAT Gang!\n"
            f"🥄 Grab a spatula — it’s flipping time.\n\n"
            f"🧠 Here’s what you can do:\n"
            f"/gm – SPATBot says hi 👋\n"
            f"/rug – sends a rug alert ⚠️\n"
            f"/wen – drops a wisdom nugget 🌕\n"
            f"/flipme – flip yourself for good luck 🥞\n"
            f"/vibe – random chill YouTube 🔗\n"
            f"/flipverse – unlock hidden lore 🧪\n"
            f"/twitter – follow the SPAT crew on Twitter 🔗\n",
            parse_mode="HTML"
        )

# 🚀 Start bot
app = ApplicationBuilder().token(TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("help", help_command))
app.add_handler(CommandHandler("flipme", flipme))
app.add_handler(CommandHandler("vibe", vibe))
app.add_handler(CommandHandler("flipverse", flipverse))
app.add_handler(CommandHandler("twitter", twitter))
app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, trigger_words))
app.add_handler(MessageHandler(filters.StatusUpdate.NEW_CHAT_MEMBERS, welcome))

keep_alive()
print("🔥 SPATBot is FLIPPING 24/7... 🥄")
app.run_polling()
